/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package py2final;

import Interfaz20.*;

/**
 *
 * @author MALDONADO
 */
public class Py2final {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        // TODO code application logic here
        uno jc = new uno();
        jc.setVisible(true);   
        System.out.println("paquete py2final main Py2final");
    }    
}
