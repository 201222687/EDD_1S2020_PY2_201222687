/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arbol_B;

/**
 *
 * @author MALDONADO
 */
public class Ordenable {
    
    public Ordenable() {

    }
       
    public boolean igualA(Ordenable o) {
        return false;
    }

    public boolean menorQue(Ordenable o) {
        return false;
    }

    public boolean mayorQue(Ordenable o) {
        return false;
    }

    public boolean menorOIgualQue(Ordenable o) {
        return false;
    }

    public boolean mayorOIgualQue(Ordenable o) {
        return false;
    }

    public Ordenable minKey() {
        return null;
    }

    public Object getKey() {
        return null;
    }
    public String getFecha(){
        return getFecha();
    }
    public void setFecha(String fecha){
        setFecha(fecha);
    }
    public int getTotal(){
        return getTotal();
    }
    public void setTotal(String total){
        setTotal(total);
    }
    
    public String getUsuario(){
        return getUsuario();
    }
    
    public String getTitulo()
    {
        return getTitulo();
    }
    
     public String getEditorial()
    {
        return getEditorial();
    }
      public String getEdicion()
    {
        return getEdicion();
    }
       public String getCategoría()
    {
        return getCategoría();
    }
        public String getIdioma()
    {
        return getIdioma();
    }
    
    
            
         
                 
                 
    public String getReferencia() {
        return getReferencia();
    }
    public void setReferencia(String referencia) {
        setReferencia(referencia);
    }
    
    
}
